thankyou for downloading.
this font is for Personal use.
dont use it for any commercial project.

link for buy : https://shoppy.gg/@stefiejustprince/groups/IpAo0ml
thank you, Regards!